﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CandyMachine
{
    class Snacks
    {
        static List<Snacks> snackslist = new List<Snacks>();
        private int priceOfSnack;
        private string name;

        public static List<Snacks> SnackList
        {
            get
            {
                return snackslist;
            }
            set
            {
                snackslist = value;
            }
        }
        public int PriceOfSnack
        {
            get
            {
                return this.priceOfSnack;
            }
            set
            {
                this.priceOfSnack = value;
            }
        }
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public Snacks(string name, int priceOfSnack)
        {
            this.name = name;
            this.priceOfSnack = priceOfSnack;
            snackslist.Add(this);

           
        }
    }

}
