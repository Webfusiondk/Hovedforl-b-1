﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CandyMachine
{
    class Machine
    {


        public string nameOfSnack;
        public int priceOfSnack;
        int howManySnackAdd;
        public int money;
        bool cancleitem;
        public void Snackinfo()
        {
            foreach (Snacks snacks in Snacks.SnackList)
            {
                Console.WriteLine("Here is your snack :" + snacks.Name + " The price is: " + snacks.PriceOfSnack);
            }
        }

        public void AddSnack()
        {
            try
            {
                Console.WriteLine("What snack will you add to the machine ");
                nameOfSnack = Console.ReadLine();
                Console.WriteLine("What is the price of the snack ");
                priceOfSnack = int.Parse(Console.ReadLine());
                Console.WriteLine("How meney snacks do you wanna add? ");
                howManySnackAdd = int.Parse(Console.ReadLine());

                for (int i = 0; i < howManySnackAdd; i++)
                {
                    Snacks newSnack = new Snacks(nameOfSnack, priceOfSnack);
                }
            }
            catch
            {
                Console.WriteLine("Incorrect input");
            }
        }

        public void BuySnack()
        {
            string userchose;
            Console.WriteLine("What snack would you like to buy?");
            Console.WriteLine("Doritos");
            Console.WriteLine("Pringels");
            Console.WriteLine("Cracker");
            userchose = Console.ReadLine().ToLower();
            if (userchose == "doritos")
            {
                Console.WriteLine("Price: " + );
            }
            else if (userchose == "pringels")
            {

            }
            else if (userchose == "cracker")
            {

            }
        }

        public void MoneyInput()
        {
            while (true)
            {
                
                Console.WriteLine("Insert amoute of money");
                money = int.Parse(Console.ReadLine());
                Console.WriteLine("Amount you have inputet: " + money);
            }
        }

        public void HardSnacks()
        {
            Snacks doritos = new Snacks("Doritos", 20);
            Snacks pringels = new Snacks("Pringels", 20);
            Snacks crackers = new Snacks("Crackers", 20);
        }

        public void EmptyMoney()
        {
            string userchoice;
            Console.WriteLine("Would you like to empty the machine? yes/no");
            userchoice = Console.ReadLine().ToLower();
            if (userchoice == "yes")
            {
                Console.WriteLine("Taking money");
                money = 0;
            }
            else
            {
                Console.WriteLine("Close the dore.");
            }
        }
    }
}
