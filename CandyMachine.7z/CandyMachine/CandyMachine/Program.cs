using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CandyMachine
{
    class Program
    {
        public static Machine mac = new Machine();
        static Program prog = new Program();
        public string userChoice;
        static void Main(string[] args)
        {
            mac.HardSnacks();
            while (true)
            {
                Console.WriteLine("Welcome to the candy machine");
                Console.WriteLine("Would you like to see the menu?");
                Console.WriteLine("Press 1 for menu");
                Console.WriteLine("Press 3 to add snack");
                Console.WriteLine("Press 4 to empty the machine for money");
                prog.userChoice = Console.ReadLine();
                prog.menu();
                Console.Clear();
            }

        }
        void menu()
        {
            switch (userChoice)
            {
                case "1":
                    mac.Snackinfo();  
                    break;
                case "2":
                    
                    break;
                case "3":
                    mac.AddSnack();
                    break;
                case "4":
                    mac.EmptyMoney();
                    break;
                default:
                    Console.WriteLine("you did not type the right input");
                    Console.WriteLine("Pleas try agien");
                    break;
            }
        }
    }
}
