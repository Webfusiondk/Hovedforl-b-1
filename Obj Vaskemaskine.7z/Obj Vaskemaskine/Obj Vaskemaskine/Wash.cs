﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Obj_Vaskemaskine
{
    class Wash
    {
        private bool power;
        public int washtime;
        public byte celcius;
        private bool open;
        public float fill;
        public string speed;
        public string whatWash;

        //Giver mig adgang til at bruge power i min program class
        public bool Power
        {
            get
            {
                return power;
            }
            set
            {
                power = value;
            }
        }
        //Giver mig adgang til at bruge open i min program class
        public bool Open
        {
            get
            {
                return open;
            }
            set
            {
                open = value;
            }
        }
        //Methode for at fylde vand på maskine før vask start
        public void Fill(float fil)
        {
            this.fill = fil;
            while (fil < 11)
            {
                Console.WriteLine("Filling the machin with water " + fil + " L...");
                fil++;
                Thread.Sleep(600);
                if (fil == 11)
                {
                    Console.WriteLine("The machine is ready for wash");
                }
            }
        }
        //Method til at bestemme washspeed
        public string WashSpeed()
        {
            switch (speed)
            {
                case "1":
                    return "The machin is now running 40mph";
                case "2":
                    return "The machin is now running 60mph";
                case "3":
                    return "The machin is now running 80mph";
                default:
                    return "The machin is running default settings now";
            }
        }
        //Method for at besteme graderne på vasken
        public byte Celcius()
        {
            celcius = 40;
            return celcius;
        }
        //Method for at bestemme længden af vaske tid
        public int WashTime()
        {
            washtime = 90;
            return washtime;
        }
        //Method for at vælge hvilken vask man vil have
        public string ChoseWash()
        {
            switch (whatWash)
            {
                case "1":
                    return "You chose normal wash";
                case "2":
                    return "You chose Eco wash";
                case "3":
                    return "You chose custom wash";
                default:
                    return "The machin is running default settings now";
            }
        }
        //Method for normalwash
        public void NormalWash()
        {
            
        }
        //Method for ecowash
        public void EcoWash()
        {

        }
    }
}
