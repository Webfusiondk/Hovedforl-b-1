using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obj_Vaskemaskine
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Gør så jeg kan kalde methoder fram min class wash
            Wash washObj = new Wash();
            washObj.NormalWash();
            washObj.EcoWash();
            //Vælg hvilken vask du vil have
            Console.WriteLine("If you would like NormalWash press 1");
            Console.WriteLine("If you would like EcoWash press 2");
            Console.WriteLine("If you would like CustomWash press 3");
            washObj.whatWash = Console.ReadLine();
            Console.WriteLine(washObj.ChoseWash());
            washObj.Fill(0);
            //Vælg hastigheden på omdringner
            Console.WriteLine("Chose washspeed 1 40mph");
            Console.WriteLine("Chose washspeed 2 60mph");
            Console.WriteLine("Chose washspeed 3 80mph");
            washObj.speed = Console.ReadLine();
            Console.WriteLine(washObj.WashSpeed());
            //Printer celcius på vask
            Console.WriteLine("The celcius of the wash: " + washObj.Celcius());
            //printer tiden på vaks
            Console.WriteLine("The time of the was is: " + washObj.WashTime());
            Console.ReadLine();
        }

    }
}
