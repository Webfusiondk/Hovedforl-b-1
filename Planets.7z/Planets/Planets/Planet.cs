﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Planets
{
    class Planet
    {
        string name;
        double mass;
        int diameter;
        int density;
        double gravity;
        double rotationPeriod;
        double dayLength;
        double distanceFromSun;
        double orbitalPeriod;
        double orbitalVelocity;
        int temperature;
        int numberOfMoons;
        bool hasRings;
        #region Properties

        //Get; set; for planets list
       public static List<Planet> Planets
        {
            get
            {
                return planets;
            }
            set
            {
                planets = value;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public double Mass
        {
            get
            {
                return this.mass;
            }
            set
            {
                this.mass = value;
            }
        }

        public int Diameter
        {
            get
            {
                return this.diameter;
            }
            set
            {
                this.diameter = value;
            }
        }

        public int Density
        {
            get
            {
                return this.density;
            }
            set
            {
                this.density = value;
            }
        }

        public double Gravity
        {
            get
            {
                return this.gravity;
            }
            set
            {
                this.gravity = value;
            }
        }

        public double RotationPeriod
        {
            get
            {
                return this.rotationPeriod;
            }
            set
            {
                this.rotationPeriod = value;
            }
        }

        public double DayLength
        {
            get
            {
                return this.dayLength;
            }
            set
            {
                this.dayLength = value;
            }
        }

        public double DistanceFromSun
        {
            get
            {
                return this.distanceFromSun;
            }
            set
            {
                this.distanceFromSun = value;
            }
        }

        public double OrbitalPeriod
        {
            get
            {
                return this.orbitalPeriod;
            }
            set
            {
                this.orbitalPeriod = value;
            }
        }

        public double OrbitalVelocity
        {
            get
            {
                return this.orbitalVelocity;
            }
            set
            {
                this.orbitalVelocity = value;
            }
        }

        public int Temperature
        {
            get
            {
                return this.temperature;
            }
            set
            {
                this.temperature = value;
            }
        }

        public int NumberOfMoons
        {
            get
            {
                return this.numberOfMoons;
            }
            set
            {
                this.numberOfMoons = value;
            }
        }

        public bool HasRings
        {
            get
            {
                return this.hasRings;
            }
            set
            {
                this.hasRings = value;
            }
        }
        #endregion


        static List<Planet> planets = new List<Planet>();

        
        public Planet(string _name, double _mass, int _diameter, int _density, double _gravity, double _rotationPeriod, double _dayLength, double _distanceFromSun, double _orbitalPeriod, double _orbitalVelocity, int _temperature, int _numberOfMoons, bool _hasRings)
        {
            this.name = _name;
            this.mass = _mass;
            this.diameter = _diameter;
            this.density = _density;
            this.gravity = _gravity;
            this.rotationPeriod = _rotationPeriod;
            this.dayLength = _dayLength;
            this.distanceFromSun = _distanceFromSun;
            this.orbitalPeriod = _orbitalPeriod;
            this.orbitalVelocity = _orbitalVelocity;
            this.temperature = _temperature;
            this.numberOfMoons = _numberOfMoons;
            this.hasRings = _hasRings;
            planets.Add(this);
        }
    }
}
