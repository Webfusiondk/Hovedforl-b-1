using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue_Operations
{
    class Program
    {
        static Program prog = new Program();
        public ScuffedBus scuffedBus = new ScuffedBus();
        public string userChoice;
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("1. Add new bus");
                Console.WriteLine("2. Remove bus");
                Console.WriteLine("3. Show the numbers of busses");
                Console.WriteLine("4. Print all busses");
                //Console.WriteLine("4. Show maximum busses and minium");
                //Console.WriteLine("5. Find a bus");
                prog.userChoice = Console.ReadLine();
                prog.Menu();
                //scuffedBus.callBus();
                Console.ReadLine();
            }
        }

        void Menu()
        {
            string bus;
            switch (userChoice)
            {
                case "1":
                    scuffedBus.AddItem();
                    break;
                case "2":
                    bus = scuffedBus.RemoveBus();
                    Console.WriteLine(bus);
                    break;
                case "3":
                    bus = scuffedBus.nextToLeave();
                    Console.WriteLine(bus);
                    break;
                case "4":
                    bus = scuffedBus.PrintBus();
                    Console.WriteLine(bus);
                    break;
                default:
                    Console.WriteLine("Did you type the right number?");
                    break;
            }
        }
    }
}
