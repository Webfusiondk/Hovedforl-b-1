﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue_Operations
{
    class Bus
    {
        string color;
        int busnumber;
        int peopleInBus;
        string destination;
        #region Propites
        public string Color
        {
            get
            {
                return this.color;
            }
            set
            {
                this.color = value;
            }
        }
        public int Busnumber
        {
            get
            {
                return this.busnumber;
            }
            set
            {
                this.busnumber = value;
            }
        }
        public int PeopleInBus
        {
            get
            {
                return this.peopleInBus;
            }
            set
            {
                this.peopleInBus = value;

            }
        }
        public string Destination
        {
            get
            {
                return this.destination;
            }
            set
            {
                this.destination = value;
            }
        }
        #endregion
        static Queue<Bus> busses = new Queue<Bus>();
        public Bus(string color, int busnumber, int peopleInBus, string destination)
        {
            this.color = color;
            this.busnumber = busnumber;
            this.peopleInBus = peopleInBus;
            this.destination = destination;
            busses.Enqueue(this);
        }
        public static Queue<Bus> Busses
        {
            get
            {
                return busses;
            }
            set
            {
                busses = value;
            }
        }
    }
}
