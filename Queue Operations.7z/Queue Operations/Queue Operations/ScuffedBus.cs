﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue_Operations
{
    class ScuffedBus
    {
        public string RemoveBus()
        {
            string bus;
            try
            {
                Bus firstToLeave = Bus.Busses.Dequeue();
                bus = string.Format("First bus to leave the Station: {0}", firstToLeave.Busnumber);
                return bus;
            }
            catch
            {
                bus = "There is no busses ready to leave";
                return bus;
            }
        }
        
        public string nextToLeave()
        {
            string nextBus;
            try
            {
                Bus nextToLeave = Bus.Busses.Peek();
                nextBus = "The next bus that is leaveing the station: ";
                return nextBus + nextToLeave.Busnumber;
            }
            catch
            {
                nextBus = "No bus ready to leave";
                return nextBus;
            }
        }
        
        public string PrintBus()
        {
            string printbus;
            foreach (Bus busses in Bus.Busses)
            {
               printbus = "Bus color: " + busses.Color + "Bus number: " + busses.Busnumber + "Bus destination: " + busses.Destination;
                return printbus;
            }
            return null;
        }

        public void AddItem()
        {
            string userColor;
            int userBusNum;
            int userPeoplInBus;
            string userDestination;
            Console.WriteLine("Add new bus");
            Console.WriteLine("Chose the color of the bus");
            try
            {
                userColor = Console.ReadLine();
                Console.WriteLine("Chose the bus number");
                userBusNum = int.Parse(Console.ReadLine());
                Console.WriteLine("Chose how meney there can be in the bus");
                userPeoplInBus = int.Parse(Console.ReadLine());
                Console.WriteLine("Chose what destantion the bus sould have");
                userDestination = Console.ReadLine();
                Bus userbus = new Bus(userColor, userBusNum, userPeoplInBus, userDestination);
            }
            catch
            {
                Console.WriteLine("Rember to type an input, and number and pepol you gotta type a number");
            }

        }
    }
}
