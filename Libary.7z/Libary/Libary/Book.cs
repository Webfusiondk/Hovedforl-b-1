﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libary
{
    class Book
    {
        string name;
        public static List<Book> Books
        {
            get
            {
                return books;
            }
            set
            {
                Books = value;
            }
        }
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        static List<Book> books = new List<Book>();//list of books
        public Book(string name)//book creation
        {
            this.name = name;
            books.Add(this);
        }
    }
}
