﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libary
{
    class LoanBook
    {//creation of the list
        public static List<string> bookAvaible = new List<string>() { "Screem Street: fang of vampire", "Screem Street: blood of the witch", "Screem Street: heart of the mummy",
                                                                      "Screem Street: flesh of the zombie", "Screem Street: claw of the werewolf" };
        public static Stack bookStack = new Stack();
        public void StackF()//or function for or stack
        {
            if (bookAvaible.Contains(Program.userLoan))
            {
                addToStack();
                removeFromlist();
            }
            else
            {
                Console.WriteLine("The book is not avaible");
            }
        }
        void addToStack()//add's book to stack
        {
            LoanBook.bookStack.Push(Program.userLoan);
            Console.WriteLine("Book {0} added to stack", Program.userLoan);
        }

        public void BookAvaible()//tjecks for book to be avaible
        {
            foreach (string prog in bookAvaible)
            {
                Console.WriteLine(prog);
            }
        }

        void removeFromlist()//remove book from list
        {
            bookAvaible.Remove(Program.userLoan);
        }
    }
}
