using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libary
{
    class Program
    {
        public static string userLoan;
        public string userChoice;
        static void Main(string[] args)
        {
            Program prog = new Program();
            //While loop to keep making choies in menu
            while (true)
            {
                Console.WriteLine("Welcome to the libarry");
                Console.WriteLine("Do you wanna loan a book or dispose?");
                Console.WriteLine("Type 1 for loan and 2 for dispose");
                prog.userChoice = Console.ReadLine();

                prog.libarryMenu();

                Console.ReadLine();
            }
        }
        //switch case to chose what part of the menu u wanna go to
        void libarryMenu()
        {
            switch (userChoice)
            {
                case "1":
                   loanBook();
                    break;
                case "2":
                    disposeBook();
                    break;
                default:
                    Console.WriteLine("Did you type 1 or 2?");
                    break;
            }
        }
        //loan book from libary
        void loanBook()
        {
            LoanBook stack = new LoanBook();
            while (true)
            {
                Console.Clear();
                Console.WriteLine("The books that are avaible");
                stack.BookAvaible();
                Console.WriteLine("");
                Console.WriteLine("What book do you wanna loan?");
                userLoan = Console.ReadLine();

                stack.StackF();
                return;
            }
        }
        //return book
        void disposeBook()
        {
            ReturnBook rb = new ReturnBook ();
            rb.bookReturn();
        }
    }
}
