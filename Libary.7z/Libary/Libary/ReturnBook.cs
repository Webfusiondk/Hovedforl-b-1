﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libary
{
    class ReturnBook
    {
        public string userid;
        public void bookReturn()
        {//method for returning book
            LoanBook stackBooks = new LoanBook();
            foreach  (string books in LoanBook.bookStack)
            {
                Console.WriteLine(books);
            }
            Console.WriteLine("Do you wanna return your book yes/no");
            userid = Console.ReadLine().ToLower();
            if (userid == "yes")
                returnBook();
        }

        void returnBook()
        {
            try
            {
                LoanBook.bookAvaible.Add(LoanBook.bookStack.Pop().ToString());
            }
            catch
            {
                Console.WriteLine("No books to return");
            }
        }
    }
}
